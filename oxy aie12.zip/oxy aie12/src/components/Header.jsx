import React, { useState, useEffect } from 'react';
import { Activity, Menu, X, Globe, User } from 'lucide-react';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'py-3' : 'py-5'
        }`}
    >
      <div className={`container mx-auto px-4 transition-all duration-300 ${scrolled ? 'bg-white/70 backdrop-blur-lg shadow-glass rounded-full border border-white/40' : ''
        }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-r from-teal-600 to-sky-500 p-2 rounded-lg text-white">
              <Activity className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">
              Oxy<span style={{ color: 'var(--color-primary)' }}>AI</span>
            </span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {['Home', 'Platform', 'Security', 'About'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-sm font-medium text-slate-600 hover:text-teal-600 transition-colors"
              >
                {item}
              </a>
            ))}
          </nav>

          {/* Actions */}
          <div className="hidden md:flex items-center gap-4">
            <button className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-teal-600 transition-colors">
              <Globe className="w-4 h-4" />
              <span>EN</span>
            </button>
            <button className="btn-primary py-2 px-4 text-sm">
              <User className="w-4 h-4" />
              <span>Patient Login</span>
            </button>
          </div>

          {/* Mobile Toggle */}
          <button
            className="md:hidden p-2 text-slate-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-white/95 backdrop-blur-xl border-b border-slate-100 p-4 shadow-lg md:hidden">
          <nav className="flex flex-col gap-4">
            {['Home', 'Platform', 'Security', 'About'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-base font-medium text-slate-600 py-2 border-b border-slate-50"
                onClick={() => setMobileMenuOpen(false)}
              >
                {item}
              </a>
            ))}
            <div className="flex flex-col gap-3 mt-4">
              <button className="btn-secondary justify-center w-full">Language: EN</button>
              <button className="btn-primary justify-center w-full">Patient Login</button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
