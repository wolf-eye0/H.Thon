import React from 'react';
import { Calendar, FileText, Lock, ChevronRight, Clock, CheckCircle } from 'lucide-react';

export default function Dashboard() {
    return (
        <section id="dashboard" className="py-20 bg-white">
            <div className="container">
                <div className="text-center mb-16">
                    <span className="text-teal-600 font-semibold tracking-wide uppercase text-xs">Patient Control Center</span>
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mt-2">
                        Your Health, <span className="text-gradient">Your Control</span>
                    </h2>
                </div>

                <div className="grid lg:grid-cols-3 gap-8">

                    {/* Appointments Widget */}
                    <div className="bg-white rounded-3xl p-6 shadow-xl border border-slate-100 flex flex-col">
                        <div className="flex items-center justify-between mb-6">
                            <div className="flex items-center gap-3">
                                <div className="bg-purple-100 p-2.5 rounded-xl text-purple-600">
                                    <Calendar className="w-5 h-5" />
                                </div>
                                <h3 className="font-bold text-slate-800">Upcoming Visits</h3>
                            </div>
                            <button className="text-xs font-semibold text-teal-600 hover:text-teal-700">View All</button>
                        </div>

                        <div className="space-y-4 mb-4">
                            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 relative group cursor-pointer hover:border-teal-200 transition-colors">
                                <div className="flex justify-between items-start mb-2">
                                    <span className="font-bold text-slate-700">Dr. Anjali Menon</span>
                                    <span className="text-xs bg-teal-100 text-teal-700 px-2 py-0.5 rounded-full">Confirmed</span>
                                </div>
                                <div className="text-sm text-slate-500 mb-2">Cardiologist • Apollo Hospital</div>
                                <div className="flex items-center gap-2 text-xs text-slate-400">
                                    <Clock className="w-3 h-3" />
                                    <span>Today, 4:30 PM</span>
                                </div>
                                <div className="absolute top-4 right-4 text-slate-300 group-hover:translate-x-1 group-hover:text-teal-500 transition-all">
                                    <ChevronRight className="w-5 h-5" />
                                </div>
                            </div>

                            <div className="p-4 bg-white border border-slate-100 rounded-2xl opacity-60">
                                <div className="flex justify-between items-start mb-2">
                                    <span className="font-bold text-slate-700">Lab Test</span>
                                    <span className="text-xs bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full">Pending</span>
                                </div>
                                <div className="text-sm text-slate-500">Full Body Profile</div>
                            </div>
                        </div>
                    </div>

                    {/* Health Records Widget */}
                    <div className="bg-white rounded-3xl p-6 shadow-xl border border-slate-100 flex flex-col">
                        <div className="flex items-center justify-between mb-6">
                            <div className="flex items-center gap-3">
                                <div className="bg-blue-100 p-2.5 rounded-xl text-blue-600">
                                    <FileText className="w-5 h-5" />
                                </div>
                                <h3 className="font-bold text-slate-800">Health Records</h3>
                            </div>
                            <button className="text-xs font-semibold text-teal-600 hover:text-teal-700">Add New</button>
                        </div>

                        <div className="space-y-2">
                            {[
                                { name: 'Blood_Work_Report.pdf', date: 'Jan 10, 2024', size: '1.2 MB' },
                                { name: 'Vaccination_Cert.pdf', date: 'Dec 15, 2023', size: '850 KB' },
                                { name: 'Prescription_XR22.jpg', date: 'Nov 02, 2023', size: '2.4 MB' },
                            ].map((file, i) => (
                                <div key={i} className="flex items-center justify-between p-3 hover:bg-slate-50 rounded-xl transition-colors cursor-pointer group">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-colors">
                                            <FileText className="w-4 h-4" />
                                        </div>
                                        <div>
                                            <p className="text-sm font-medium text-slate-700 group-hover:text-blue-600 transition-colors truncate max-w-[120px]">{file.name}</p>
                                            <p className="text-[10px] text-slate-400">{file.date} • {file.size}</p>
                                        </div>
                                    </div>
                                    <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-500" />
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Consent Manager Widget */}
                    <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-6 shadow-xl text-white flex flex-col">
                        <div className="flex items-center justify-between mb-6">
                            <div className="flex items-center gap-3">
                                <div className="bg-white/10 p-2.5 rounded-xl text-teal-400">
                                    <Lock className="w-5 h-5" />
                                </div>
                                <h3 className="font-bold">Consent Manager</h3>
                            </div>
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                        </div>

                        <div className="flex-1 flex flex-col justify-center space-y-4">
                            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-sm font-medium text-slate-200">Dr. Smith (Apollo)</span>
                                    <div className="w-8 h-5 bg-teal-500/30 rounded-full flex items-center p-0.5 cursor-pointer">
                                        <div className="w-4 h-4 bg-teal-400 rounded-full shadow-sm translate-x-3 transition-transform"></div>
                                    </div>
                                </div>
                                <p className="text-xs text-slate-400">Access to: Medications, Allergies</p>
                                <p className="text-[10px] text-teal-300/80 mt-1">Expires: 24 Hours</p>
                            </div>

                            <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                                <div className="flex items-center justify-between mb-2">
                                    <span className="text-sm font-medium text-slate-200">Insurance Co.</span>
                                    <div className="w-8 h-5 bg-slate-600 rounded-full flex items-center p-0.5 cursor-pointer">
                                        <div className="w-4 h-4 bg-slate-400 rounded-full shadow-sm transition-transform"></div>
                                    </div>
                                </div>
                                <p className="text-xs text-slate-400">Access to: Billing History</p>
                            </div>
                        </div>

                        <button className="mt-6 w-full py-3 bg-teal-600 hover:bg-teal-500 rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2">
                            <CheckCircle className="w-4 h-4" /> Update Permissions
                        </button>
                    </div>

                </div>
            </div>
        </section>
    );
}
