import React from 'react';
import { Mic, Brain, Shield, Database, Activity, Languages } from 'lucide-react';

const features = [
    {
        icon: <Brain className="w-6 h-6 text-teal-600" />,
        title: "Agentic Intelligence",
        description: "Autonomous agents that handle scheduling, triage, and follow-ups with human-like understanding."
    },
    {
        icon: <Languages className="w-6 h-6 text-blue-600" />,
        title: "Regional Voice Support",
        description: "Native Malayalam & multilingual voice interaction. Speak naturally, we understand perfectly."
    },
    {
        icon: <Database className="w-6 h-6 text-purple-600" />,
        title: "RAG Medical Accuracy",
        description: "Grounded in verified medical journals and patient history. No hallucinations, just facts."
    },
    {
        icon: <Shield className="w-6 h-6 text-green-600" />,
        title: "ABDM & UHI Ready",
        description: "Seamlessly integrated with India's National Digital Health Mission infrastructure."
    },
    {
        icon: <Activity className="w-6 h-6 text-red-600" />,
        title: "Proactive Care",
        description: "Continuous monitoring suggests preventive measures before issues become critical."
    },
    {
        icon: <Mic className="w-6 h-6 text-orange-600" />,
        title: "Natural Dialogue",
        description: "Conversational interface that feels less like a form and more like a doctor visit."
    }
];

export default function Features() {
    return (
        <section id="platform" className="py-20 bg-white relative">
            <div className="container">
                <div className="text-center max-w-2xl mx-auto mb-16">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                        Built for <span className="text-gradient">Trust & Empathy</span>
                    </h2>
                    <p className="text-slate-600">
                        Our platform combines cutting-edge LLMs with strict medical guardrails to deliver safe, effective, and accessible healthcare to everyone.
                    </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {features.map((feature, index) => (
                        <div
                            key={index}
                            className="group p-8 bg-slate-50 border border-slate-100 rounded-2xl transition hover:shadow-xl hover:bg-white hover:-translate-y-1 duration-300"
                        >
                            <div className="w-14 h-14 rounded-xl bg-white shadow-sm flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                                {feature.icon}
                            </div>
                            <h3 className="text-xl font-bold text-slate-800 mb-3">{feature.title}</h3>
                            <p className="text-slate-600 leading-relaxed">{feature.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
