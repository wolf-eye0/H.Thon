import React from 'react';
import { ArrowRight, ShieldCheck, Sparkles, MessageCircle } from 'lucide-react';

export default function Hero() {
    return (
        <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
            {/* Background Decor */}
            <div className="absolute top-0 left-0 w-full h-full bg-grid -z-10"></div>
            <div className="absolute top-20 right-0 w-[500px] h-[500px] bg-teal-200/20 rounded-full blur-3xl -z-10 animate-pulse"></div>
            <div className="absolute bottom-0 left-20 w-[300px] h-[300px] bg-sky-200/20 rounded-full blur-3xl -z-10"></div>

            <div className="container grid lg:grid-cols-2 gap-12 items-center">

                {/* Left Content */}
                <div className="space-y-8 animate-fadeIn">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-50 border border-teal-100 text-teal-700 text-sm font-medium">
                        <Sparkles className="w-4 h-4" />
                        <span>Next-Gen Agentic Healthcare AI</span>
                    </div>

                    <h1 className="text-5xl lg:text-7xl font-bold leading-tight tracking-tight text-slate-900">
                        Healthcare that <br />
                        <span className="text-gradient">Understands You</span>
                    </h1>

                    <p className="text-lg text-slate-600 max-w-lg leading-relaxed">
                        Experience the future of patient engagement with Oxy AI.
                        AI agents that listen, understand, and care—powered by deep medical knowledge and empathy.
                    </p>

                    <div className="flex flex-wrap items-center gap-4">
                        <button className="btn-primary text-lg px-8 py-3 shadow-teal-500/20">
                            Start Consultation <ArrowRight className="w-5 h-5" />
                        </button>
                        <button className="btn-secondary text-lg px-8 py-3">
                            View Demo
                        </button>
                    </div>

                    <div className="flex items-center gap-6 pt-4 text-sm text-slate-500 font-medium">
                        <div className="flex items-center gap-2">
                            <ShieldCheck className="w-5 h-5 text-teal-600" />
                            <span>HIPAA Compliant</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-blue-500 to-teal-400 flex items-center justify-center text-[10px] text-white font-bold">AI</div>
                            <span>99.9% Accuracy</span>
                        </div>
                    </div>
                </div>

                {/* Right Visual - Animated Cards */}
                <div className="relative h-[500px] w-full hidden lg:block perspective-1000">

                    {/* Main Card */}
                    <div className="absolute top-10 left-10 w-80 glass-panel p-6 z-20 animate-float">
                        <div className="flex items-center gap-4 mb-4">
                            <div className="w-12 h-12 rounded-full bg-teal-100 flex items-center justify-center">
                                <MessageCircle className="w-6 h-6 text-teal-600" />
                            </div>
                            <div>
                                <h3 className="font-bold text-slate-800">Dr. Oxy AI</h3>
                                <p className="text-xs text-teal-600">Active • Listening</p>
                            </div>
                        </div>
                        <div className="space-y-3">
                            <div className="p-3 bg-slate-50 rounded-lg rounded-tl-none text-sm text-slate-700 shadow-sm">
                                Hello! I noticed your recent lab reports. Would you like me to explain the cholesterol levels?
                            </div>
                            <div className="p-3 bg-teal-600 text-white rounded-lg rounded-tr-none text-sm shadow-md ml-auto max-w-[90%]">
                                Yes, please explain it in simple Malayalam.
                            </div>
                            <div className="h-1 w-full bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full w-2/3 bg-teal-400 animate-pulse"></div>
                            </div>
                            <p className="text-[10px] text-slate-400 text-right">Processing voice & text...</p>
                        </div>
                    </div>

                    {/* Floating Elements */}
                    <div className="absolute top-40 right-10 w-64 glass-panel p-5 z-10 animate-float delay-200">
                        <div className="flex items-center justify-between mb-3">
                            <span className="text-sm font-semibold text-slate-700">Health Score</span>
                            <span className="text-sm font-bold text-teal-600">92/100</span>
                        </div>
                        <div className="h-2 w-full bg-slate-100 rounded-full">
                            <div className="h-full w-[92%] bg-gradient-to-r from-teal-400 to-blue-500 rounded-full"></div>
                        </div>
                        <div className="mt-3 flex gap-2">
                            <span className="px-2 py-1 bg-green-100 text-green-700 text-[10px] rounded-md">Vitals Stable</span>
                            <span className="px-2 py-1 bg-blue-100 text-blue-700 text-[10px] rounded-md">Vaccinated</span>
                        </div>
                    </div>

                    <div className="absolute bottom-20 left-20 w-60 glass-panel p-4 z-30 animate-float delay-300">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                                <ShieldCheck className="w-5 h-5 text-orange-500" />
                            </div>
                            <div>
                                <h4 className="font-bold text-sm text-slate-800">Data Secure</h4>
                                <p className="text-[10px] text-slate-500">End-to-end Encrypted</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    );
}
