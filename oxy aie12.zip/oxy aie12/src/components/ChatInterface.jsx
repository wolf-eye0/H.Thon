import React, { useState } from 'react';
import { Send, Mic, Paperclip, MoreVertical, PlayCircle } from 'lucide-react';

const initialMessages = [
    { id: 1, sender: 'bot', text: 'Namaste! I am your health assistant. How are you feeling today?', time: '10:00 AM' },
    { id: 2, sender: 'user', text: 'I have a mild fever and headache since morning.', time: '10:02 AM' },
    { id: 3, sender: 'bot', text: 'I understand. Have you taken any medication yet? Also, could you please record your temperature if possible?', time: '10:02 AM' }
];

export default function ChatInterface() {
    const [messages, setMessages] = useState(initialMessages);
    const [input, setInput] = useState('');

    const handleSend = () => {
        if (!input.trim()) return;
        setMessages([...messages, { id: Date.now(), sender: 'user', text: input, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
        setInput('');
        setTimeout(() => {
            setMessages(prev => [...prev, { id: Date.now() + 1, sender: 'bot', text: 'I have noted that. Based on your inputs, I recommend scheduling a quick tele-consultation. Shall I proceed?', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
        }, 1500);
    };

    return (
        <section className="py-20 bg-slate-50 relative overflow-hidden">
            {/* Decorative blobs */}
            <div className="absolute top-1/2 left-1/4 w-[600px] h-[600px] bg-teal-200/20 rounded-full blur-[100px] -translate-y-1/2 pointer-events-none"></div>

            <div className="container lg:flex items-center gap-12">
                <div className="lg:w-1/2 mb-10 lg:mb-0 space-y-6">
                    <h2 className="text-3xl md:text-4xl font-bold text-slate-900">
                        Talk to Oxy AI <br />
                        <span className="text-gradient">Just like a specialist</span>
                    </h2>
                    <p className="text-lg text-slate-600 leading-relaxed">
                        Our AI understands medical context, local dialects, and even emotions.
                        Whether you type "I'm not feeling well" or speak "Enikku sukhamilla" (Malayalam),
                        Oxy AI processes it accurately with RAG-based medical precision.
                    </p>
                    <ul className="space-y-4">
                        <li className="flex items-center gap-3 bg-white p-4 rounded-xl shadow-sm border border-slate-100">
                            <div className="bg-teal-100 p-2 rounded-lg"><Mic className="w-5 h-5 text-teal-700" /></div>
                            <div>
                                <strong className="block text-slate-800">Voice-First Experience</strong>
                                <span className="text-sm text-slate-500">Multilingual STT & TTS Support</span>
                            </div>
                        </li>
                        <li className="flex items-center gap-3 bg-white p-4 rounded-xl shadow-sm border border-slate-100">
                            <div className="bg-blue-100 p-2 rounded-lg"><PlayCircle className="w-5 h-5 text-blue-700" /></div>
                            <div>
                                <strong className="block text-slate-800">Instant Triage</strong>
                                <span className="text-sm text-slate-500">Immediate symptom analysis & guidance</span>
                            </div>
                        </li>
                    </ul>
                </div>

                <div className="lg:w-1/2">
                    {/* Chat Mobile Phone Frame / Card */}
                    <div className="bg-white rounded-[2rem] shadow-glass border border-slate-200 overflow-hidden max-w-md mx-auto">
                        {/* Header */}
                        <div className="bg-gradient-to-r from-teal-600 to-sky-600 p-4 flex items-center justify-between text-white">
                            <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-full bg-white/20 border-2 border-white/50 flex items-center justify-center">
                                    <span className="font-bold">O</span>
                                </div>
                                <div>
                                    <h4 className="font-bold text-sm">Oxy AI Assistant</h4>
                                    <p className="text-[10px] text-teal-100 flex items-center gap-1">
                                        <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span> Online
                                    </p>
                                </div>
                            </div>
                            <MoreVertical className="w-5 h-5 opacity-80 cursor-pointer" />
                        </div>

                        {/* Messages */}
                        <div className="h-[400px] overflow-y-auto p-4 space-y-4 bg-slate-50">
                            {messages.map((msg) => (
                                <div
                                    key={msg.id}
                                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div
                                        className={`max-w-[80%] p-3 rounded-2xl shadow-sm text-sm ${msg.sender === 'user'
                                            ? 'bg-gradient-to-br from-teal-600 to-teal-700 text-white rounded-tr-sm'
                                            : 'bg-white border border-slate-100 text-slate-700 rounded-tl-sm'
                                            }`}
                                    >
                                        <p>{msg.text}</p>
                                        <p className={`text-[10px] mt-1 text-right ${msg.sender === 'user' ? 'text-teal-200' : 'text-slate-400'}`}>
                                            {msg.time}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>

                        {/* Input Area */}
                        <div className="p-3 bg-white border-t border-slate-100 flex items-center gap-2">
                            <button className="p-2 text-slate-400 hover:text-teal-600 transition-colors">
                                <Paperclip className="w-5 h-5" />
                            </button>
                            <div className="flex-1 relative">
                                <input
                                    type="text"
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    placeholder="Type or speak..."
                                    className="w-full pl-4 pr-10 py-2.5 bg-slate-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/50"
                                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                                />
                                <button className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-white rounded-full shadow-sm text-teal-600 hover:scale-110 transition-transform">
                                    <Mic className="w-3.5 h-3.5" />
                                </button>
                            </div>
                            <button
                                onClick={handleSend}
                                className="p-3 bg-teal-600 text-white rounded-full shadow-md hover:bg-teal-700 transition-colors"
                            >
                                <Send className="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
