import React from 'react';
import { Activity, Twitter, Linkedin, Facebook } from 'lucide-react';

export default function Footer() {
    return (
        <footer className="bg-slate-900 text-white pt-20 pb-10">
            <div className="container">
                <div className="grid md:grid-cols-4 gap-12 mb-16">
                    <div className="col-span-1 md:col-span-2">
                        <div className="flex items-center gap-2 mb-6">
                            <div className="bg-white/10 p-2 rounded-lg text-teal-400">
                                <Activity className="w-6 h-6" />
                            </div>
                            <span className="text-xl font-bold tracking-tight">
                                Oxy<span className="text-teal-400">AI</span>
                            </span>
                        </div>
                        <p className="text-slate-400 leading-relaxed max-w-sm">
                            Empowering patients with AI-driven healthcare intelligence.
                            Secure, empathetic, and always available.
                        </p>
                    </div>

                    <div>
                        <h4 className="font-bold text-lg mb-6">Platform</h4>
                        <ul className="space-y-4 text-slate-400">
                            <li><a href="#" className="hover:text-teal-400 transition-colors">Patient Portal</a></li>
                            <li><a href="#" className="hover:text-teal-400 transition-colors">Doctor Dashboard</a></li>
                            <li><a href="#" className="hover:text-teal-400 transition-colors">AI Diagnostics</a></li>
                            <li><a href="#" className="hover:text-teal-400 transition-colors">Integration API</a></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="font-bold text-lg mb-6">Legal</h4>
                        <ul className="space-y-4 text-slate-400">
                            <li><a href="#" className="hover:text-teal-400 transition-colors">Privacy Policy</a></li>
                            <li><a href="#" className="hover:text-teal-400 transition-colors">Terms of Service</a></li>
                            <li><a href="#" className="hover:text-teal-400 transition-colors">HIPAA Compliance</a></li>
                        </ul>
                    </div>
                </div>

                <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
                    <p className="text-slate-500 text-sm">© 2024 Oxy AI. All rights reserved.</p>
                    <div className="flex gap-4">
                        <a href="#" className="text-slate-400 hover:text-white transition-colors"><Twitter className="w-5 h-5" /></a>
                        <a href="#" className="text-slate-400 hover:text-white transition-colors"><Linkedin className="w-5 h-5" /></a>
                        <a href="#" className="text-slate-400 hover:text-white transition-colors"><Facebook className="w-5 h-5" /></a>
                    </div>
                </div>
            </div>
        </footer>
    );
}
